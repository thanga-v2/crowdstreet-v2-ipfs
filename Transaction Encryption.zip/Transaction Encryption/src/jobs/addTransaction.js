const ethers = require('ethers');
const fs = require('fs');
const path = require("path");
require('dotenv');
const provider = new ethers.providers.JsonRpcProvider(process.env.JSON_RPC_PROVIDER || "https://matic-mumbai.chainstacklabs.com");
// input privatekey from backend # MINTER ADDRESS
const privateKey = process.env.ADMIN_PRIVATEKEY || "37611e38b150420410f1eff5163d060dcc349274445980847a751f0f7960453d";
const wallet = new ethers.Wallet(privateKey, provider);
const contractAddress = process.env.CONTRACT_ADDRES || "0xe4d0042E0B6b3156729459b0c8e6f099831f523c";
const filePath = path.join(__dirname, '../../config/abi/Transaction.json');
const abi = JSON.parse(fs.readFileSync(filePath, 'utf8'));
const contract = new ethers.Contract(contractAddress, abi, wallet);
/* to be filled by backend
--------------------------*/

// uint id;
// bytes32 transactionIdHash;
// bytes32 bankIdHash;
// bool isCompletedTransaction;
// uint stageTransaction;
// uint investorId;
// uint listingId;
// uint offeringAmount;
// string documentHash;
// string investingAccName;


(async() => {
    var nonce = Math.floor(new Date().getTime() / 1000);

    let transactionObj = [
        1001,
        ethers.utils.solidityKeccak256(["address", "uint256"],[wallet.address, nonce]),
        ethers.utils.solidityKeccak256(["address", "uint256"],[wallet.address, nonce]),  
        true,  
        1,
        1, 
        1,
        100, 
        "qwertyu", 
        "qwertyui"
    ]
    try {
        var  txnReceipt = await contract.addTransaction(transactionObj,{gasPrice: ethers.utils.parseUnits("50", "gwei"), gasLimit: 400000});
        txnReceipt = await txnReceipt.wait();
        // Mint is actually transfer in blockchain
        tokenId = txnReceipt.events[0].data;
        console.log("transactionId:", tokenId, "transactionHash:", txnReceipt.transactionHash);
    } catch(e) {
        console.log(e)
    }
})();